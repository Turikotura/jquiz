create definer = root@localhost view quizzes_view as
select `q`.`id`                                                                                  AS `id`,
       `q`.`title`                                                                               AS `title`,
       `q`.`author_id`                                                                           AS `author_id`,
       `q`.`created_at`                                                                          AS `created_at`,
       `q`.`time`                                                                                AS `time`,
       `q`.`thumbnail`                                                                           AS `thumbnail`,
       `q`.`thumbnail_url`                                                                       AS `thumbnail_url`,
       `q`.`should_mix_up`                                                                       AS `should_mix_up`,
       `q`.`show_all`                                                                            AS `show_all`,
       `q`.`auto_correct`                                                                        AS `auto_correct`,
       `q`.`allow_practice`                                                                      AS `allow_practice`,
       `q`.`description`                                                                         AS `description`,
       count(`h`.`id`)                                                                           AS `total_play_count`,
       sum((case
                when (`h`.`completed_at` >= (curdate() - interval 1 month)) then 1
                else 0 end))                                                                     AS `last_month_play_count`
from (`quizDB`.`quizzes` `q` left join `quizDB`.`history` `h` on ((`q`.`id` = `h`.`quiz_id`)))
group by `q`.`id`, `q`.`title`;

